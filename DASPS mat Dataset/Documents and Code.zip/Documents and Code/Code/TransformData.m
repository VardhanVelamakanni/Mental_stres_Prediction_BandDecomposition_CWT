for i=1:12
datas1{i,1}= reshape(data(:,:,i),14,1920)
end